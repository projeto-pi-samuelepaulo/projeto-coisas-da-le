from django.contrib.auth import views as auth_views
from django.urls import path
from . import views

app_name = 'produtos'

urlpatterns = [
    path('', views.lista_produtos, name='lista'),
    path('produto/<int:id>/', views.detalhe_produto, name='detalhe'),
    path('cadastro/', views.cadastro, name='cadastro'),
    path('login/', auth_views.LoginView.as_view(template_name='produtos/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(), name='logout'),
    path('carrinho/', views.carrinho, name='carrinho'),
    path('carrinho/adicionar/<int:id>/', views.adicionar_carrinho, name='adicionar_carrinho'),
    path('carrinho/remover/<int:id>/', views.remover_carrinho, name='remover_carrinho'),
    path('pagamento/', views.pagamento, name='pagamento'),
]
