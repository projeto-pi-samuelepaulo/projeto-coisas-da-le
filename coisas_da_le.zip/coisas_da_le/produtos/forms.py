from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User


class CadastroForm(UserCreationForm):
    email = forms.EmailField(required=True)

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']


class PagamentoForm(forms.Form):
    nome = forms.CharField(max_length=100, label='Nome no pagamento')
    numero = forms.CharField(max_length=19, label='Número do cartão')
    validade = forms.CharField(max_length=7, label='Validade')
    cvv = forms.CharField(max_length=4, label='CVV', widget=forms.PasswordInput)
