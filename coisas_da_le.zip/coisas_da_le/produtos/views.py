from decimal import Decimal

from django.contrib import messages
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from .forms import CadastroForm, PagamentoForm
from .models import ItemPedido, Pedido, Produto


def lista_produtos(request):
    produtos = Produto.objects.all()
    return render(request, 'produtos/lista.html', {'produtos': produtos})


def detalhe_produto(request, id):
    produto = get_object_or_404(Produto, id=id)
    return render(request, 'produtos/detalhe.html', {'produto': produto})


def cadastro(request):
    if request.method == 'POST':
        form = CadastroForm(request.POST)
        if form.is_valid():
            usuario = form.save()
            login(request, usuario)
            return redirect('produtos:lista')
    else:
        form = CadastroForm()
    return render(request, 'produtos/cadastro.html', {'form': form})


def adicionar_carrinho(request, id):
    produto = get_object_or_404(Produto, id=id)
    carrinho = request.session.get('carrinho', {})
    chave = str(produto.id)
    carrinho[chave] = carrinho.get(chave, 0) + 1
    request.session['carrinho'] = carrinho
    return redirect('produtos:carrinho')


def carrinho(request):
    carrinho = request.session.get('carrinho', {})
    itens = []
    total = Decimal('0.00')

    for produto_id, quantidade in carrinho.items():
        produto = get_object_or_404(Produto, id=int(produto_id))
        subtotal = produto.preco * quantidade
        total += subtotal
        itens.append({
            'produto': produto,
            'quantidade': quantidade,
            'subtotal': subtotal,
        })

    return render(request, 'produtos/carrinho.html', {'itens': itens, 'total': total})


def remover_carrinho(request, id):
    carrinho = request.session.get('carrinho', {})
    carrinho.pop(str(id), None)
    request.session['carrinho'] = carrinho
    return redirect('produtos:carrinho')


@login_required
def pagamento(request):
    carrinho = request.session.get('carrinho', {})
    if not carrinho:
        messages.warning(request, 'Seu carrinho está vazio.')
        return redirect('produtos:lista')

    total = Decimal('0.00')
    produtos = []
    for produto_id, quantidade in carrinho.items():
        produto = get_object_or_404(Produto, id=int(produto_id))
        total += produto.preco * quantidade
        produtos.append((produto, quantidade))

    if request.method == 'POST':
        form = PagamentoForm(request.POST)
        if form.is_valid():
            pedido = Pedido.objects.create(
                usuario=request.user,
                total=total,
                pago=True,
            )
            for produto, quantidade in produtos:
                ItemPedido.objects.create(
                    pedido=pedido,
                    produto=produto,
                    quantidade=quantidade,
                    preco=produto.preco,
                )
            request.session['carrinho'] = {}
            messages.success(request, f'Pedido #{pedido.id} realizado com sucesso!')
            return redirect('produtos:lista')
    else:
        form = PagamentoForm()

    return render(request, 'produtos/pagamento.html', {'form': form, 'total': total})
